import DashboardClient from './DashboardClient'

export default function Dashboard() {
  return <DashboardClient />
}